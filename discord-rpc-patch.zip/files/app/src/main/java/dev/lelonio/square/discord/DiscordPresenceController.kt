package dev.lelonio.square.discord

import android.content.Context
import androidx.media3.common.C
import androidx.media3.common.Player
import dev.lelonio.square.backend.youtube.YouTubeBackend
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import timber.log.Timber
import kotlin.math.abs

/**
 * Watches the player and keeps the Discord presence in step with it.
 *
 * Polled once a second rather than listener-driven on purpose: the service
 * replaces its player when the backend changes, and a poll that always reads
 * the current one has nothing to re-attach. It only talks to Discord when
 * something worth saying has changed (the track, play/pause, or a seek), so
 * the cost of the polling is a handful of property reads.
 *
 * What is shown:
 *   header  - "Listening to {artist}"   (the activity name)
 *   line 1  - {title}                   (details)
 *   line 2  - {artist}                  (state)
 *   image   - the cover, album as its hover text
 */
object DiscordPresenceController {

    private const val TAG = "DiscordSvc"
    private const val TICK_MS = 1_000L
    private const val SEEK_TOLERANCE_MS = 3_000L

    private var job: Job? = null

    fun attach(
        context: Context,
        scope: CoroutineScope,
        playerProvider: () -> Player,
    ) {
        detach()
        val app = context.applicationContext
        val store = DiscordStore.get(app)
        DiscordRpcManager.init(app)

        job = scope.launch {
            var lastKey: String? = null
            var lastStartMs = 0L
            var wasEnabled = store.enabled.value

            while (isActive) {
                try {
                    val enabled = store.enabled.value
                    if (!enabled) {
                        if (wasEnabled || lastKey != null) {
                            DiscordRpcManager.clear()
                            lastKey = null
                        }
                        wasEnabled = false
                        delay(TICK_MS)
                        continue
                    }
                    wasEnabled = true

                    // Connecting is the settings page's business; until the
                    // gateway says READY there is nothing to send to, and what
                    // was sent before a reconnect is gone, so start over.
                    if (!DiscordRpcManager.isReady()) {
                        lastKey = null
                        delay(TICK_MS)
                        continue
                    }

                    val player = playerProvider()
                    val item = player.currentMediaItem
                    val metadata = item?.mediaMetadata
                    val title = metadata?.title?.toString()?.takeIf { it.isNotBlank() }
                    val idle = player.playbackState == Player.STATE_IDLE ||
                        player.playbackState == Player.STATE_ENDED

                    if (item == null || title == null || idle) {
                        if (lastKey != null) {
                            DiscordRpcManager.clear()
                            lastKey = null
                        }
                        delay(TICK_MS)
                        continue
                    }

                    val playing = player.isPlaying
                    val now = System.currentTimeMillis()
                    val position = player.currentPosition.coerceAtLeast(0L)
                    val startMs = now - position
                    val showButton = store.showButton.value

                    val key = "${item.mediaId}|$playing|$showButton"
                    val moved = playing && abs(startMs - lastStartMs) > SEEK_TOLERANCE_MS
                    if (key != lastKey || moved) {
                        send(
                            mediaId = item.mediaId,
                            title = title,
                            artist = metadata?.artist?.toString()?.takeIf { it.isNotBlank() },
                            album = metadata?.albumTitle?.toString()?.takeIf { it.isNotBlank() },
                            artwork = metadata?.artworkUri?.toString(),
                            playing = playing,
                            startMs = startMs,
                            durationMs = player.duration.takeIf { it != C.TIME_UNSET && it > 0L }
                                ?: metadata?.durationMs?.takeIf { it > 0L },
                            showButton = showButton,
                        )
                        lastKey = key
                        lastStartMs = startMs
                    }
                } catch (e: kotlinx.coroutines.CancellationException) {
                    throw e
                } catch (e: Throwable) {
                    Timber.tag(TAG).w(e, "presence tick failed")
                }
                delay(TICK_MS)
            }
        }
    }

    fun detach() {
        job?.cancel()
        job = null
        runCatching { DiscordRpcManager.clear() }
    }

    private fun send(
        mediaId: String,
        title: String,
        artist: String?,
        album: String?,
        artwork: String?,
        playing: Boolean,
        startMs: Long,
        durationMs: Long?,
        showButton: Boolean,
    ) {
        val (buttonLabel, buttonUrl) = if (showButton) buttonFor(mediaId) else (null to null)
        // Paused: no timestamps, so Discord stops drawing a progress bar that
        // would keep running while the music does not.
        val activity = DiscordActivity(
            activityType = DiscordActivity.TYPE_LISTENING,
            name = artist ?: title,
            state = artist ?: "",
            details = title,
            startTimestamp = if (playing) startMs else 0L,
            endTimestamp = if (playing && durationMs != null) startMs + durationMs else null,
            largeImage = artwork?.takeIf { it.startsWith("http://") || it.startsWith("https://") },
            largeText = album,
            smallImage = null,
            smallText = null,
            button1Label = buttonLabel,
            button1Url = buttonUrl,
            button2Label = null,
            button2Url = null,
        )
        DiscordRpcManager.setActivity(activity, songId = mediaId, isPlaying = playing)
    }

    /** A link only for what has one; a local file has nowhere to point. */
    private fun buttonFor(mediaId: String): Pair<String?, String?> {
        if (mediaId.startsWith(YouTubeBackend.TRACK_PREFIX)) {
            val id = mediaId.removePrefix(YouTubeBackend.TRACK_PREFIX)
            if (VIDEO_ID.matches(id)) {
                return "Listen on YouTube Music" to "https://music.youtube.com/watch?v=$id"
            }
        }
        val spotify = mediaId.removePrefix("spotify:track:")
        if (mediaId.startsWith("spotify:track:") && SPOTIFY_ID.matches(spotify)) {
            return "Listen on Spotify" to "https://open.spotify.com/track/$spotify"
        }
        return null to null
    }

    private val VIDEO_ID = Regex("^[A-Za-z0-9_-]{11}$")
    private val SPOTIFY_ID = Regex("^[A-Za-z0-9]{22}$")
}
