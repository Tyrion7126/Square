package dev.lelonio.square.discord

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * What the Discord presence is allowed to do. The account itself (the OAuth
 * tokens) lives in [DiscordTokenStore]; this holds only the two switches.
 */
class DiscordStore private constructor(context: Context) {

    private val prefs = context.applicationContext
        .getSharedPreferences("discord_rpc", Context.MODE_PRIVATE)

    private val _enabled = MutableStateFlow(prefs.getBoolean(KEY_ENABLED, true))

    /** Whether what is playing is shown on the profile at all. */
    val enabled: StateFlow<Boolean> = _enabled.asStateFlow()

    fun setEnabled(value: Boolean) {
        if (value == _enabled.value) return
        _enabled.value = value
        prefs.edit().putBoolean(KEY_ENABLED, value).apply()
    }

    private val _showButton = MutableStateFlow(prefs.getBoolean(KEY_BUTTON, true))

    /** The "Listen on ..." button under the presence card. */
    val showButton: StateFlow<Boolean> = _showButton.asStateFlow()

    fun setShowButton(value: Boolean) {
        if (value == _showButton.value) return
        _showButton.value = value
        prefs.edit().putBoolean(KEY_BUTTON, value).apply()
    }

    companion object {
        private const val KEY_ENABLED = "enabled"
        private const val KEY_BUTTON = "show_button"

        @Volatile
        private var instance: DiscordStore? = null

        fun get(context: Context): DiscordStore =
            instance ?: synchronized(this) {
                instance ?: DiscordStore(context).also { instance = it }
            }
    }
}
