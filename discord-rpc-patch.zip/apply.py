#!/usr/bin/env python3
"""Pasang Discord RPC ke Square. Dijalankan dari root repo oleh workflow.

Setiap penggantian dicek: teks yang dicari harus ada tepat satu kali, kalau
tidak skrip berhenti dengan pesan jelas (artinya Square berubah dan patch
perlu disesuaikan). Aman dijalankan dua kali.
"""
import pathlib
import shutil
import sys

HERE = pathlib.Path(__file__).resolve().parent
ROOT = pathlib.Path.cwd()
APP_ID = "1566132566581452850"

SERVICE = ROOT / "app/src/main/java/dev/lelonio/square/playback/PlaybackService.kt"
SETTINGS = ROOT / "app/src/main/java/dev/lelonio/square/ui/settings/SettingsScreen.kt"
MANIFEST = ROOT / "app/src/main/AndroidManifest.xml"
GRADLE = ROOT / "app/build.gradle.kts"


def edit(path, old, new, marker):
    text = path.read_text(encoding="utf-8")
    if marker in text:
        print(f"= {path.name}: sudah terpasang ({marker})")
        return
    n = text.count(old)
    if n != 1:
        sys.exit(f"GAGAL {path}: bagian yang dicari ditemukan {n}x (harus 1x):\n{old[:200]}")
    path.write_text(text.replace(old, new), encoding="utf-8")
    print(f"+ {path.name}: {marker}")


# 1. file baru
src = HERE / "files"
for f in src.rglob("*"):
    if f.is_file():
        dest = ROOT / f.relative_to(src)
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(f, dest)
print("+ file paket discord disalin")

# 2. gradle: App ID, ktor, hanya arm64
edit(
    GRADLE,
    'buildConfigField("boolean", "VERBOSE_LOG", "false")\n',
    'buildConfigField("boolean", "VERBOSE_LOG", "false")\n'
    f'        buildConfigField("long", "DISCORD_APP_ID", "{APP_ID}L")\n',
    "DISCORD_APP_ID",
)
edit(
    GRADLE,
    "    implementation(libs.okhttp)\n",
    "    implementation(libs.okhttp)\n"
    "    implementation(libs.ktor.client.core)\n"
    "    implementation(libs.ktor.client.okhttp)\n",
    "libs.ktor.client.okhttp",
)
edit(
    GRADLE,
    'val nativeAbis = listOf("arm64-v8a", "armeabi-v7a")',
    'val nativeAbis = listOf("arm64-v8a")',
    'listOf("arm64-v8a")',
)

# 3. manifest: activity penerima redirect OAuth
edit(
    MANIFEST,
    '        <activity\n            android:name=".ui.MainActivity"',
    '        <activity\n'
    '            android:name=".discord.DiscordOAuthActivity"\n'
    '            android:exported="true"\n'
    '            android:theme="@android:style/Theme.Translucent.NoTitleBar">\n'
    '            <intent-filter>\n'
    '                <action android:name="android.intent.action.VIEW" />\n'
    '                <category android:name="android.intent.category.DEFAULT" />\n'
    '                <category android:name="android.intent.category.BROWSABLE" />\n'
    '                <data android:scheme="squarediscord" android:host="oauth2" android:path="/callback" />\n'
    '            </intent-filter>\n'
    '        </activity>\n\n'
    '        <activity\n            android:name=".ui.MainActivity"',
    "DiscordOAuthActivity",
)

# 4. PlaybackService: pasang dan lepas
edit(
    SERVICE,
    "        player.addListener(buttonsListener)\n\n"
    "        scope.launch {\n"
    "            container.likedStore.likedTracks.collect {",
    "        player.addListener(buttonsListener)\n\n"
    "        dev.lelonio.square.discord.DiscordPresenceController.attach(\n"
    "            context = this,\n"
    "            scope = scope,\n"
    "            playerProvider = { player },\n"
    "        )\n\n"
    "        scope.launch {\n"
    "            container.likedStore.likedTracks.collect {",
    "DiscordPresenceController.attach",
)
edit(
    SERVICE,
    "    override fun onDestroy() {\n        SessionKeeper.engine = null\n",
    "    override fun onDestroy() {\n"
    "        dev.lelonio.square.discord.DiscordPresenceController.detach()\n"
    "        SessionKeeper.engine = null\n",
    "DiscordPresenceController.detach",
)

# 5. SettingsScreen: satu bagian di grup "listening" pada halaman Playback
edit(
    SETTINGS,
    "        // Spotify's DJ: offered and played with its voice, or kept out of sight.\n",
    '        // Discord: what is playing, on the profile.\n'
    '        if (shown == SettingsPage.Playback && "listening" in openGroups) groupItem("discord-rpc", Group.LISTENING) {\n'
    "            DiscordSection(backdrop)\n"
    "        }\n\n"
    "        // Spotify's DJ: offered and played with its voice, or kept out of sight.\n",
    'groupItem("discord-rpc"',
)
settings_text = SETTINGS.read_text(encoding="utf-8")
if "private fun DiscordSection" not in settings_text:
    block = (HERE / "DiscordSection.kt.txt").read_text(encoding="utf-8")
    SETTINGS.write_text(settings_text.rstrip("\n") + "\n\n" + block, encoding="utf-8")
    print("+ SettingsScreen.kt: DiscordSection")
print("selesai")
